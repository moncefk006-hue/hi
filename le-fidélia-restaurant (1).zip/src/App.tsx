import React, { useEffect, useState } from 'react';
import { MapPin, Phone, Clock, Coffee, UtensilsCrossed, Music, ArrowRight, CheckCircle, CarFront, Accessibility, Wifi, Map, MessageCircle, Instagram } from 'lucide-react';
import { motion } from 'motion/react';

export default function App() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const businessInfo = {
    name: "Le Fidélia",
    address: "7 Rue de l'Emir Abdelkrim El Khettabi, Alger Centre 16000",
    phone: "+213778968556",
    whatsapp: "+213778968556",
    googleMaps: "https://maps.app.goo.gl/dGc75RdreWPiQG1bA",
    hours: [
      { day: "Lundi - Jeudi", hours: "08:30 – 23:00" },
      { day: "Vendredi", hours: "15:00 – 00:00" },
      { day: "Samedi - Dimanche", hours: "08:30 – 23:00" }
    ]
  };

  return (
    <div className="min-h-screen relative selection:bg-brand-green selection:text-white">
      {/* Navigation */}
      <header className={`fixed top-0 w-full z-50 transition-all duration-500 ${scrolled ? 'bg-brand-light/90 backdrop-blur-md py-4 shadow-sm' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
          <div className="text-2xl font-serif font-semibold tracking-wide text-brand-green uppercase">
            {businessInfo.name}
          </div>
          <div className="hidden md:flex gap-8 text-sm font-medium tracking-widest uppercase">
            <a href="#services" className="luxury-underline">Services</a>
            <a href="#ambiance" className="luxury-underline">L'Ambiance</a>
            <a href="#contact" className="luxury-underline">Contact</a>
          </div>
          <a href="#contact" className="hidden md:inline-flex items-center justify-center px-6 py-2 border border-brand-green text-brand-green text-sm uppercase tracking-widest hover:bg-brand-green hover:text-white transition-colors duration-300 rounded-full">
            Réserver
          </a>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen min-h-[600px] flex items-center justify-center pt-20">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&q=80&w=1920" 
            alt="Interior of Le Fidélia restaurant" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-brand-light/85 backdrop-blur-[2px]"></div>
          {/* Subtle gradient overlay to enhance text readability while keeping it light */}
          <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-brand-light to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 w-full grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
          <div className="md:col-span-1 border-l border-brand-green/20 h-full hidden md:flex items-center pl-4">
            <div className="vertical-text text-brand-green tracking-[0.2em] uppercase text-xs font-semibold">
              Restaurant &mdash; Alger Centre
            </div>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="md:col-span-11 max-w-3xl"
          >
            <h1 className="text-5xl md:text-7xl lg:text-[100px] leading-[0.9] font-serif font-light text-brand-green tracking-tight mb-6">
              L'Élégance <br className="hidden md:block"/>
              <span className="italic text-brand-green/80">au cœur</span> d'Alger.
            </h1>
            <p className="text-lg md:text-xl text-brand-ink/70 font-light mb-10 max-w-xl leading-relaxed">
              Une expérience culinaire d'exception. Dégustez nos spécialités, du déjeuner décontracté au dîner intime rythmé par nos concerts en direct.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a href={`tel:${businessInfo.phone}`} className="inline-flex items-center justify-center px-8 py-4 bg-brand-green text-white text-sm uppercase tracking-widest hover:bg-brand-green/90 transition-colors duration-300 rounded-full">
                Nous Contacter <ArrowRight className="ml-2 w-4 h-4" />
              </a>
              <a href={`https://wa.me/${businessInfo.whatsapp.replace('+', '')}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center px-8 py-4 bg-transparent border border-brand-green text-brand-green text-sm uppercase tracking-widest hover:bg-brand-green/5 transition-colors duration-300 rounded-full">
                <MessageCircle className="mr-2 w-4 h-4" /> WhatsApp
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Intro/Services Grid */}
      <section id="services" className="py-24 md:py-32 bg-brand-light">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-2 gap-16 lg:gap-24 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="order-2 md:order-1"
          >
            <div className="flex items-center gap-4 mb-6 text-brand-green uppercase tracking-widest text-xs font-semibold">
              <span className="w-8 h-[1px] bg-brand-green"></span>
              L'Offre
            </div>
            <h2 className="text-4xl md:text-5xl font-serif text-brand-green mb-8 leading-tight">
              Des saveurs pour <br/> <span className="italic">chaque instant.</span>
            </h2>
            <p className="text-brand-ink/70 font-light leading-relaxed mb-8">
              Que vous veniez pour un brunch matinal, un repas d'affaires, ou un dîner romantique, Le Fidélia vous propose une carte riche et variée. Découvrez notre bar à salade, nos plats végétariens et nos fabuleux desserts.
            </p>
            
            <ul className="space-y-4">
              {[
                { icon: Coffee, text: "Excellents cafés et pâtisseries" },
                { icon: UtensilsCrossed, text: "Service à table, de 8h30 à 23h" },
                { icon: Music, text: "Concerts et ambiance musicale" }
              ].map((item, idx) => (
                <li key={idx} className="flex items-center gap-4 text-brand-ink/80">
                  <span className="flex items-center justify-center w-10 h-10 rounded-full border border-brand-green/20 text-brand-green">
                    <item.icon className="w-5 h-5" />
                  </span>
                  <span className="text-sm font-medium tracking-wide">{item.text}</span>
                </li>
              ))}
            </ul>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="order-1 md:order-2 grid grid-cols-2 gap-4"
          >
            <div className="space-y-4 pt-12">
              <div className="aspect-[3/4] overflow-hidden rounded-2xl">
                <img src="https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&q=80&w=600" alt="Nos Desserts" className="w-full h-full object-cover hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
              </div>
            </div>
            <div className="space-y-4">
              <div className="aspect-[3/4] overflow-hidden rounded-2xl">
                <img src="https://images.unsplash.com/photo-1536935338788-846bb9981813?auto=format&fit=crop&q=80&w=600" alt="Excellents Cocktails" className="w-full h-full object-cover hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Ambiance & Lifestyle */}
      <section id="ambiance" className="py-24 md:py-32 bg-[#eeece7]">
        <div className="max-w-7xl mx-auto px-6 md:px-12 text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif text-brand-green mb-6">
            Une Ambiance <span className="italic">Unique</span>
          </h2>
          <p className="text-brand-ink/70 max-w-2xl mx-auto font-light leading-relaxed">
            Un cadre branché, agréable et romantique. Idéal pour partager de petites portions entre amis, un déjeuner d'affaires ou un moment en solo. 
          </p>
        </div>

        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { tag: "Adapté aux groupes", title: "Convivialité", desc: "Terrasse spacieuse et petites portions à partager." },
            { tag: "Ambiance", title: "Calme & Branché", desc: "Un lieu qui s'adapte à votre rythme, du matin jusqu'à tard le soir." },
            { tag: "Privilège", title: "Salle Privée", desc: "Une salle à manger privée disponible pour vos événements spéciaux." }
          ].map((feature, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="bg-white p-8 rounded-3xl border border-black/5 hover:shadow-xl transition-shadow duration-300"
            >
              <span className="inline-block px-3 py-1 bg-brand-green/5 text-brand-green text-xs font-semibold uppercase tracking-widest rounded-full mb-6">
                {feature.tag}
              </span>
              <h3 className="text-2xl font-serif text-brand-green mb-4">{feature.title}</h3>
              <p className="text-brand-ink/70 font-light leading-relaxed text-sm">
                {feature.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Trust & Convenience */}
      <section className="py-24 bg-brand-light border-b border-black/5">
        <div className="max-w-4xl mx-auto px-6 md:px-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-x-8 gap-y-12 text-center">
            <div className="flex flex-col items-center">
              <Accessibility className="w-8 h-8 text-brand-green mb-4 opacity-80" />
              <h4 className="font-medium text-sm mb-2 text-brand-green">100% Accessible</h4>
              <p className="text-xs text-brand-ink/60">Entrée et parking accessibles</p>
            </div>
            <div className="flex flex-col items-center">
              <Wifi className="w-8 h-8 text-brand-green mb-4 opacity-80" />
              <h4 className="font-medium text-sm mb-2 text-brand-green">Wi-Fi Gratuit</h4>
              <p className="text-xs text-brand-ink/60">Connectivité pour tous</p>
            </div>
            <div className="flex flex-col items-center">
              <CarFront className="w-8 h-8 text-brand-green mb-4 opacity-80" />
              <h4 className="font-medium text-sm mb-2 text-brand-green">Stationnement</h4>
              <p className="text-xs text-brand-ink/60">Parking gratuit dans la rue</p>
            </div>
            <div className="flex flex-col items-center">
              <CheckCircle className="w-8 h-8 text-brand-green mb-4 opacity-80" />
              <h4 className="font-medium text-sm mb-2 text-brand-green">Familles</h4>
              <p className="text-xs text-brand-ink/60">Menu adapté aux enfants</p>
            </div>
          </div>
        </div>
      </section>

      {/* Location & Contact */}
      <section id="contact" className="py-24 md:py-32 bg-brand-light">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-2 gap-16">
          <div>
            <h2 className="text-4xl md:text-5xl font-serif text-brand-green mb-8">
              Venez <span className="italic">nous voir.</span>
            </h2>
            <p className="text-brand-ink/70 font-light mb-12 max-w-md">
              Idéalement sis à Alger Centre, Le Fidélia vous accueille tout au long de la semaine. Réservations recommandées.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <MapPin className="w-5 h-5 text-brand-green mt-1" />
                <div>
                  <h4 className="text-sm font-semibold uppercase tracking-widest text-brand-green mb-1">Adresse</h4>
                  <a href={businessInfo.googleMaps} target="_blank" rel="noopener noreferrer" className="text-brand-ink/80 hover:text-brand-green transition-colors leading-relaxed block max-w-[280px]">
                    {businessInfo.address}
                  </a>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <Clock className="w-5 h-5 text-brand-green mt-1" />
                <div>
                  <h4 className="text-sm font-semibold uppercase tracking-widest text-brand-green mb-2">Horaires d'ouverture</h4>
                  <ul className="text-brand-ink/80 space-y-2 text-sm">
                    {businessInfo.hours.map((h, i) => (
                      <li key={i} className="flex justify-between w-48">
                        <span>{h.day}</span>
                        <span className="font-medium">{h.hours}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="w-5 h-5 text-brand-green mt-1" />
                <div>
                  <h4 className="text-sm font-semibold uppercase tracking-widest text-brand-green mb-1">Réservations</h4>
                  <p className="text-brand-ink/80 text-sm mb-4">Cartes bancaires acceptées</p>
                  <div className="flex gap-4">
                    <a href={`tel:${businessInfo.phone}`} className="text-lg font-serif text-brand-green hover:underline">
                      {businessInfo.phone}
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="relative h-[400px] md:h-auto rounded-3xl overflow-hidden border border-black/5 bg-gray-100 flex items-center justify-center group">
            <div className="absolute inset-0 bg-black/5 group-hover:bg-black/0 transition-colors duration-500 z-10 pointer-events-none"></div>
            <a href={businessInfo.googleMaps} target="_blank" rel="noopener noreferrer" className="absolute inset-0 z-20 flex items-center justify-center">
                <div className="bg-white/90 backdrop-blur px-6 py-3 rounded-full shadow-lg text-brand-green text-sm font-semibold tracking-wider uppercase flex items-center gap-2 transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                  <Map className="w-4 h-4" /> Voir sur Google Maps
                </div>
            </a>
            {/* Using a map placeholder image for aesthetic reasons instead of an interactive map iframe which can be clunky, falling back to linking to the real Maps app */}
             <img 
              src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=1000" 
              alt="Map view of Alger Centre" 
              className="w-full h-full object-cover opacity-60 grayscale group-hover:grayscale-0 transition-all duration-700"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-brand-green text-brand-light pt-12 pb-8 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-8">
            <div className="text-2xl font-serif text-white uppercase tracking-widest">
              {businessInfo.name}
            </div>
            <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6 text-xs font-semibold tracking-widest uppercase opacity-70 text-center md:text-left">
              <span>© {new Date().getFullYear()} Le Fidélia</span>
              <span className="hidden md:inline">•</span>
              <span>Restaurant à Alger Centre</span>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 flex justify-center text-[10px] sm:text-xs font-semibold tracking-[0.2em] uppercase opacity-70">
            <a href="https://instagram.com/hype_moncef" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-white transition-colors duration-300 group">
              <span>Design & Création par</span>
              <span className="flex items-center gap-1.5 underline-offset-4 group-hover:underline">
                <Instagram className="w-3.5 h-3.5" /> @hype_moncef
              </span>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

